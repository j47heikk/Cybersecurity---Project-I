
CREATE TABLE User (
    id varchar(30) PRIMARY KEY,
    firstname varchar(200),
    phone varchar (12),
    hetu varchar (12)
)
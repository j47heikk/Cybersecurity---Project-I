package sec.project.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.security.SecureRandom;
import java.math.BigInteger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import sec.project.repository.SignupRepository;

@Controller
public class SignupController {

    
    @Autowired
    private SignupRepository signupRepository;

    @RequestMapping("*")
    public String defaultMapping() {
        return "redirect:/login";
    }
    
    // Login form
  @RequestMapping(value = "/login", method = RequestMethod.GET)
  public String login() {
      
      System.out.println("inLoginGet");
      return "login";
  }

  @RequestMapping(value = "/login", method = RequestMethod.POST)
  public String loginPost() {
      System.out.println("inLoginPost");
    return "form";
  }
  
  // Login form with error
  @RequestMapping(value = "/login-error", method = RequestMethod.GET)
  public String loginError(Model model) {
    model.addAttribute("loginError", true);
    return "login";
  }

    @RequestMapping(value = "/form", method = RequestMethod.GET)
    public String loadForm() {
        
      System.out.println("inLoginPost");
        return "form";
    }

    @RequestMapping(value = "/form", method = RequestMethod.POST)
    public String submitForm(@RequestParam String name, @RequestParam String address) throws SQLException {
        // signupRepository.save(new Signup(name, address));
        
      System.out.println("inFormPost");
        String databaseAddress = "jdbc:h2:file:./database";
        Connection connection = null;
        
        connection  = DriverManager.getConnection(databaseAddress, "sa","");
        SecureRandom secureRandom = new SecureRandom();
        String random = new BigInteger(130, secureRandom).toString(30);
        // OWASP Injection flaw
        Statement insertStatement = null;
        insertStatement = connection.createStatement();//("INSERT INTO user (id, name) VALUES ("+ name+","+address+")");
        insertStatement.execute("INSERT INTO user VALUES ('"+random+"', '+ name+','+address+', '')");
        insertStatement.close();
        readUsersFromDB(connection);
        return "done";
    }
    
    private static void readUsersFromDB(Connection connection) throws SQLException {
        PreparedStatement statement =
            connection.prepareStatement("SELECT id, firstname FROM user");
        ResultSet rs = statement.executeQuery();
      
        while (rs.next()) {
            String id = rs.getString("id");
            String name = rs.getString("firstname");
                     
            System.out.println(id + " " + name);
        }
        rs.close();
           }
    
}
